package com.sermax.preview;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import android.text.InputType;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(7,17,13);
    private final int panel = Color.rgb(16,31,24);
    private final int green = Color.rgb(57,232,121);
    private final int white = Color.rgb(232,242,236);
    private final int muted = Color.rgb(151,174,160);
    private LinearLayout chat;
    private TextView modeStatus;
    private boolean pcMode = true;
    private EditText input;
    private LinearLayout root;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(dp(16), dp(12), dp(16), dp(12));
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("SERMAX", 25, green, true);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView version = text("PRÉVIA v0.1", 11, muted, true);
        header.addView(version);
        root.addView(header);

        TextView subtitle = text("ASSISTENTE LOCAL • DEMONSTRAÇÃO", 11, muted, false);
        subtitle.setPadding(0, dp(4), 0, dp(12));
        root.addView(subtitle);

        LinearLayout modeBox = new LinearLayout(this);
        modeBox.setOrientation(LinearLayout.VERTICAL);
        modeBox.setPadding(dp(12), dp(10), dp(12), dp(10));
        modeBox.setBackground(round(panel, 14));
        modeStatus = text("", 14, white, true);
        modeBox.addView(modeStatus);
        TextView modeNote = text("Os modos são simulados nesta versão.", 12, muted, false);
        modeNote.setPadding(0, dp(4), 0, 0);
        modeBox.addView(modeNote);
        root.addView(modeBox);

        Button switchMode = button("Alternar modo PC / celular");
        switchMode.setOnClickListener(v -> {
            pcMode = !pcMode;
            updateMode();
            addBubble("Sistema", pcMode
                ? "Modo PC selecionado. Nenhum computador está conectado nesta prévia."
                : "Modo celular selecionado. A IA local ainda não está integrada.", false);
        });
        LinearLayout.LayoutParams switchLp = new LinearLayout.LayoutParams(-1, dp(46));
        switchLp.topMargin = dp(8);
        root.addView(switchMode, switchLp);
        updateMode();

        TextView historyTitle = text("CONVERSA", 12, green, true);
        historyTitle.setPadding(0, dp(16), 0, dp(8));
        root.addView(historyTitle);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        chat = new LinearLayout(this);
        chat.setOrientation(LinearLayout.VERTICAL);
        chat.setPadding(0, 0, 0, dp(8));
        scroll.addView(chat);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        addBubble("SERMAX", "Olá! Esta é a prévia instalável da interface SERMAX.", false);
        addBubble("SERMAX", "O chat funciona localmente para demonstrar a navegação. Nenhuma API ou crédito é usado.", false);

        LinearLayout composer = new LinearLayout(this);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Escreva uma mensagem...");
        input.setHintTextColor(muted);
        input.setTextColor(white);
        input.setTextSize(14);
        input.setPadding(dp(12), 0, dp(12), 0);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setBackground(round(panel, 12));
        composer.addView(input, new LinearLayout.LayoutParams(0, dp(50), 1));
        Button send = button("Enviar");
        LinearLayout.LayoutParams sendLp = new LinearLayout.LayoutParams(dp(82), dp(50));
        sendLp.leftMargin = dp(8);
        composer.addView(send, sendLp);
        send.setOnClickListener(v -> sendMessage());
        root.addView(composer);
        TextView foot = text("SEM API • SEM CRÉDITOS • SEM CONEXÃO REAL", 10, muted, false);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(10), 0, 0);
        root.addView(foot);
    }

    private void updateMode() {
        modeStatus.setText(pcMode ? "● Modo PC • desconectado" : "● Modo celular • simulado");
        modeStatus.setTextColor(pcMode ? green : white);
    }

    private void sendMessage() {
        String msg = input.getText().toString().trim();
        if (msg.isEmpty()) return;
        addBubble("Você", msg, true);
        input.setText("");
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
            .hideSoftInputFromWindow(input.getWindowToken(), 0);
        String reply = pcMode
            ? "Demonstração: o modo PC está selecionado, mas não há conexão real configurada."
            : "Demonstração: o modo celular está selecionado, mas o modelo local ainda não foi integrado.";
        addBubble("SERMAX • SIMULAÇÃO", reply, false);
    }

    private void addBubble(String who, String message, boolean user) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(10), dp(12), dp(10));
        box.setBackground(round(user ? Color.rgb(17,54,34) : panel, 12));
        TextView title = text(who, 11, user ? green : muted, true);
        TextView body = text(message, 14, white, false);
        body.setPadding(0, dp(4), 0, 0);
        box.addView(title);
        box.addView(body);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(8);
        chat.addView(box, lp);
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextSize(12); b.setTextColor(bg);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(round(green, 12));
        return b;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        return d;
    }
    private int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density + 0.5f); }
}
